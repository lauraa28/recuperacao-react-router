import { NavLink } from 'react-router-dom';
import './Header.css';
export default function Header(){return <header className="header"><NavLink className="brand" to="/"><span className="brand-mark">◇</span><span>DIGITAL<br/><b>PROJECT</b></span></NavLink><nav><NavLink to="/">MAIN</NavLink><NavLink to="/gallery">GALLERY</NavLink><NavLink to="/projects">PROJECTS</NavLink><NavLink to="/certifications">CERTIFICATIONS</NavLink><NavLink to="/contacts">CONTACTS</NavLink></nav></header>}
